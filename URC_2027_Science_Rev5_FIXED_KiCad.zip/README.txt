URC 2027 SCIENCE PACKAGE - REV 5 PRELIMINARY SCHEMATIC

Open the .kicad_sch in KiCad 8/9/10. Symbols are self-contained in the schematic.

NOT FABRICATION READY. All schematic blocks are functional placeholders, NOT manufacturer parts.
Net labels are conceptual. Electrical values, protections, connectors, and pinout require selection and verification.

Derived from provided Science_Package_Engineering(1).xlsx and Science_Package_Flowchart(1).pdf.
J1 12 V input; F1 protection TBD; U1 12-to-5 V converter TBD; U2 5-to-3.3 V regulator TBD.
J2 rover controller; J3 sensors; J4 actuator control; J5 optional independent 24 V motor feed.
TP1-TP6 proposed measurement pads.

IMPORTANT: Input TVS, filter, regulator feedback/passives, output capacitors, and driver circuitry are not designed.
The optional 24 V feed is a separate PDB harness, not a 24 V PCB rail.
No selected science sensor or sampling actuator has been confirmed.

REV 5 FIX: Corrected invalid text justification entries that caused KiCad schematic parse failure at line 59. S-expression balance checked. KiCad application/ ERC not available in this environment; verify load and ERC locally.
